package Lesson10;

public class Citizen extends Person {
}
