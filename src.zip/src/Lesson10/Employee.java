package Lesson10;

public class Employee extends Person {
}
