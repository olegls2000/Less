package Lesson10;

public class Person {
}
