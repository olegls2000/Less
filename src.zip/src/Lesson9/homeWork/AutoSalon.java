package Lesson9.homeWork;

public interface AutoSalon {
    int buyCar(Car car);

    void sellCar(int parkingSlot);

    void report();
}
