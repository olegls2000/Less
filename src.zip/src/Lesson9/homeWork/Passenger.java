package Lesson9.homeWork;

public class Passenger extends Car {
    private int places;

    public int getPlaces() {
        return places;
    }
}
