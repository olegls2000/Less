package Lesson9.homeWork;

public class Truck extends Car {
    private int bearing;

    public int getBearing() {
        return bearing;
    }
}
