package Lesson9.observer;

public interface Observer {
    void getEvent(String forecast);
}
