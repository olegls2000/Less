package lesson8;

public interface WithPerimetr extends WithSquare {

    int calculatePerimetr();
}
