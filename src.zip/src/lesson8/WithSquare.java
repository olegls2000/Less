package lesson8;

public interface WithSquare {
    public static final double MY_PI  = 3.14;
    public double calculateSquare();


}
