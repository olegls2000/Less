package myClasses;

public class Car {
    //TODO add some fields
}
